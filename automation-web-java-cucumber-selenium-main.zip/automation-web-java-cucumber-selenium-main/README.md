How to Run the project automation-api that build by
Java, Cucumber JVM technology

Sample test project to demo Open API

=== Run Program Instruction ===

Standard 
* Java 1.8

=== How to run by terminal ===

- First, unzip/ decompress the project folder
- Open using your IDE Tools
- Please ensure the JDK versioning is following 
  the standard
- Open your terminal and go to directory project
  automation-api
- Input 'mvn test' or 'mvn clean test' on your terminal
- Done

=== How to run by IDE Tools ===
- First, unzip/ decompress the project folder
- Open using your IDE Tools
- Please ensure the JDK versioning is following
  the standard
- Press button 'play/ run' in your IDE Tools 
- Choose 'Runner.class' as a main class to running
- Done
